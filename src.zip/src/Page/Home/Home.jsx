import './Home.css'
function Home() {
    return (
        <div className='home-container'>
            <h1>Introduce yourself</h1>
            <div className='introduce-container'>
                <div className='img-container'>
                </div>
                <div className='text-container'>
                    <h2><u>NungUmSudNaRak</u></h2>
                    <br />
                    <p className='text'>
                        My fullname is Puripat Wongtangton.
                        <br />
                        I'm 21 years old.
                        <br />
                        I'm student at Sripatum University.
                        <br />
                        I'm a programmer.
                        <br />
                        I'm not interested in programming.
                        <br />
                        My hobby is sleeping.
                        <br />
                        My favorite food is noodles.
                        <br />
                        My favorite color is black. 
                    </p>
                </div>
            </div>
        </div>
    )
}

export default Home