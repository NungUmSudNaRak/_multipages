import './Header.css'

function Header() {
    return (
        <div className='header-container'>
            <span className='badge bg-dark'><h1>Csi205 front end software devolopment</h1></span>
        </div>
    )
}

export default Header